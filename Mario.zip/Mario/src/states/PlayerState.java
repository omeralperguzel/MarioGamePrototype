package states;

public enum PlayerState {

    BIG, SMALL, DEAD
}
