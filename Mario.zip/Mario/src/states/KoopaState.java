package states;

public enum KoopaState {
    WALKING, SHELL, SPINNING
}
