package main;

public enum Id {
    player, wall, mushroom, goomba, powerUp, pipe, coin, koopa, flag; //flag eklendi
}
