# Project exclude paths
/out/
