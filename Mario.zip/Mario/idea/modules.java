<?xml version="1.0" encoding="UTF-8"?>
<project version="4">
  <component name="ProjectModuleManager">
    <modules>
      <module fileurl="file://$PROJECT_DIR$/MarioGame1.iml" filepath="$PROJECT_DIR$/MarioGame1.iml" />
    </modules>
  </component>
</project>